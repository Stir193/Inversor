# Mobile - Inversor (Expo)
Recomendaciones:
- Ajusta las URLs en los fetchs (192.168.1.100:4000) por la IP local de tu PC.
- cd mobile && npm install
- expo start
- Abre en Expo Go (iOS/Android) o en emulador.
