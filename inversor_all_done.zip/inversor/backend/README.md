# Backend - Inversor (MVP)
Instrucciones:
1. cd backend
2. npm install
3. copia .env.example a .env y ajusta JWT_SECRET
4. npm run dev
Base de datos SQLite: se crea data.db en la raíz del repo.


## Nuevos endpoints
- GET /api/prices?ticker=SYMBOL  -> requiere ALPHAVANTAGE_KEY en .env
- GET /api/export/transactions -> export CSV (token required)

Seed:
- Ejecuta `node seed.js` en la carpeta backend para crear un usuario de prueba (test@example.com / password123)
