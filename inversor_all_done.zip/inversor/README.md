# Inversor - MVP completo (Backend + Mobile)
Contenido:
- backend/: Node + Express + SQLite
- mobile/: Expo React Native app

Pasos rápidos:
1. Backend:
   - cd backend
   - npm install
   - cp .env.example .env  (modifica JWT_SECRET)
   - npm run dev
2. Mobile:
   - cd mobile
   - npm install
   - expo start
   - modifica en mobile/src/screens los endpoints al IP de tu máquina (ej 192.168.x.x:4000)

Si quieres que genere también:
- Dockerfile y docker-compose
- Integración con una API de precios (Finnhub/AlphaVantage)
- Script para exportar CSV desde backend
- Un zip con archivos listos para deploy en Render/Heroku

Dime qué más quieres y lo agrego.


## Deploy rápido en Render / Heroku (sugerencia)

- **Backend**: Configura un servicio Node (Render/Heroku) apuntando a la carpeta `backend`. Variables de entorno importantes:
  - JWT_SECRET, ALPHAVANTAGE_KEY (opcional), FINNHUB_KEY (opcional), PORT (por defecto 4000).
  - En Heroku, agrega buildpack Node y asegúrate de ejecutar `npm install` y `npm start`.

- **Web**: Puedes desplegar la carpeta `web` como una app estática (build con `npm run build`) en Netlify / Vercel o usar Render Static Site. Alternativamente, usa Docker en Render para construir y servir la app.

- **Usando Docker Compose** (local/deploy): `docker-compose up --build` levantará tres servicios:
  - backend: http://localhost:4000
  - web (Vite dev): http://localhost:5173
  - nginx proxy: http://localhost (serve web + proxy /api to backend)

- **SSL / Producción**: Para producción usa Nginx con certificados (Let's Encrypt) y asegúrate de construir la web (`npm run build`) y servirla desde un servidor de archivos estático (nginx). Para el backend, considera PostgreSQL en vez de SQLite.



## Preparar repo y subir a GitHub

Puedes inicializar el repo localmente con:

```
./create_repo.sh
# o manualmente
# git init
# git add .
# git commit -m "Initial commit"
# git remote add origin https://github.com/your-user/inversor.git
# git branch -M main
# git push -u origin main
```

Si tienes la CLI `gh` instalada, puedes crear y subir en un solo paso:

```
gh repo create youruser/inversor --public --source=. --remote=origin --push
```
